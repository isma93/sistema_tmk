<table>

<tr>
						
						<th>id_nota_interna</th>
						
                     
					
					   
					
                    

                    <th>id_cliente</th>
						<th>fecha_ingreso</th>div
						<th>id_entidad</th>								
						<th>nombre_entidad</th>
                        <th>marca_entidad</th>
                        <th>id_uso</th>
                        <th>uso_nota_egreso</th>
                        <th>id_canal</th>
                        <th>nombre_canal</th>
                        <th>id_cargo_entidad</th>
                        <th>cargo_entidad</th>
                        <th>nombre_entidad</th>
                        <th>id_ruta</th>
                        <th>nombre_ruta</th>
                        <th>autorizado_por</th>
                        <th>cuenta_contable</th>
                        <th>nombre_cuenta</th>
                        <th>codigo_producto</th>
                        <th>cantidad</th>
                        <th>observaciones</th>
                        <th>solicitante</th>
                        <th>decripcion_promocion</th>
</table>