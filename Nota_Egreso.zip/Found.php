<html>
<?php
echo '<script>
													  
										 window.location = "Index.php";
										
									</script>'; ?>
</body>




</html>