<html>
	
<head>
<?php
session_start(); 
unset($_SESSION['canales']);
?>
	<title>MOSTRAR DATOS</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
	</head>	
		<body>
		
		<?php
			
			include('include/config.inc');
			$conexion = mysqli_connect($servidor,$usuario,$contrasena,$basededatos);
			mysqli_set_charset($conexion,"utf8");
				$idc=$_POST["codigoCliente"];
				$rev = "false";
				$cid=$_SESSION['codigo_empleado'];
				$canalcliente=$_POST["canales"];
				$posruta=$_POST["rutacliente"];
				if ($canalcliente>0)
				{

					$query="UPDATE tmp_cookie SET Tmp_estado = $canalcliente, ruta_S2 = $posruta Where ID='$cid'";
					$resultado=mysqli_query( $conexion, $query ) or die ( "No se pueden mostrar los registros");
					$rev="true";
					
				}

				$_SESSION['canales']=$canalcliente;
				
				$_SESSION['rutacliente']=$_POST["rutacliente"];
				
				//if ($_SESSION['canalcliente']=1){$_SESSION['cn1']="P";}
					

			
			if ($rev="true"){
			$query="Select*from cliente where id_cliente= '$idc';";
			$resultado=mysqli_query( $conexion, $query ) or die ( "No se pueden mostrar los registros");
			if ($resultado){
			while ($row=mysqli_fetch_array($resultado))
				{
					$_SESSION['id_cliente']=$row['id_cliente'];
					$_SESSION['nom']=$row['nombre_cliente'];
					$_SESSION['direccion'] = $row['direccion_cliente'];
					$_SESSION['municipio']=$row['id_municipio'];
					
				}
			}else 
			{
				
				echo '<script> Swal.fire({
					icon: "error",
					title: "El codigo de cliente ingresado no existe",
					allowOutsideClick: false,
					showConfirmButton: true,
					confirmButtonText: "Continuar"
					}).then(function(result){
					   if(result.value){                   
					    window.location = "create_invoice.php";
					   }
					});</script>';
			}
		}

		if (isset($_SESSION['nom']))
		{


		}else {
			echo '<script> Swal.fire({
				icon: "error",
				title: "El codigo de cliente ingresado no existe",
				allowOutsideClick: false,
				showConfirmButton: true,
				confirmButtonText: "Continuar"
				}).then(function(result){
				   if(result.value){                   
				    window.location = "create_invoice.php";
				   }
				});</script>';

		}
			
			/*
			echo"<table width='100%' border='1' align='center'>";
			echo "<tr>";
			echo "<TH>idAlumno</TH>
					<TH>Nombre</TH>
					<TH>Direccion</TH>
					<TH>Edad</TH>
					<TH></TH>
					<TH></TH>";
			echo "</tr>";
			while ($row=mysqli_fetch_array($resultado))
				{
					echo "<tr>";				
					echo "<td>",$row['id_cliente'],"</td>";
					echo "<td>",$row['nombre_cliente'],"</td>";
					echo "<td>",$row['direccion'],"</td>";
					echo "<td>",$row['municipio'],"</td>";
							
					echo "</tr>";
				}
			echo "</table>";
			*/
			//CERRAR CONEXIÓN DE BASE DE DATOS
			
			if (isset($_SESSION['nom'])){
				
				$query="Select*from canal;";
				$resultado=mysqli_query( $conexion, $query ) or die ( "No se pueden mostrar los canales");
				$i = 0;
				while ($row=mysqli_fetch_array($resultado))
					{
						$_SESSION['id_canal'.$i]=$row['id_canal'];
						$_SESSION['canal'.$i]=$row['nombre_canal'];
						echo $_SESSION['canal'.$i];
						$_SESSION['numero_de_canales']=$i;
						$i++;					
				}
				
					
						
						
							mysqli_close( $conexion );	


							//header("Location:create_invoice.php");
							//echo '<meta http-equiv="Refresh" content="0;url=create_invoice.php"> ';
							
								echo '<script>
													  
										 window.location = "create_invoice.php";
										
									</script>';
									
									
						
									
						
						
				}
			else {
						mysqli_close( $conexion );	
				}
			//header("Location:create_invoice.php");
		?>
		<BR>
		
		</body>
</html>