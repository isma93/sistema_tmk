<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src=
"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
    <script src="js/invoice.js"></script>
    <script>
            function init()
            {
               window.location.href = "ViewReport.php";
            }
</script>

<div class="row row-cols-1 row-cols-md-2 g-4" >
 
  <div class="col" >
    <div class="card"><a  onclick="parent.location.href = 'ViewReportExcel.php'"  href="#">
      <img src="../images/layouts/viewpdf.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">REPORTE EXCEL</h5>
        <p class="card-text">Modulo de autorizados.</p></a>
      </div>
    </div>
  </div><br>
  <div class="col">
    <div class="card"><a onclick="parent.location.href = 'ViewReportpdf.php'" href="#">
      <img src="../images/layouts/viewpdf.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">REPORTE PDF</h5>
        <p class="card-text">Modulo de autorizados para impresion.</p></a>
      </div>
    </div>
  </div><br>
  <div class="col">
    <div class="card"><!--<a href="#work">-->
      <img src="../images/layouts/viewpdfdisable.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">REPORTE ANULADOS</h5>
        <p class="card-text">Modulo de notas anuladas.</p></a>
      </div>
    </div>
  </div><br>
  <div class="col">
    <div class="card"><!--<a href="#work">-->
      <img src="../images/layouts/viewpdfdisable.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">MODULO PENDIENTES DE AUTORIZAR</h5>
        <p class="card-text">Modulo notas pendientes de autorizacion.</p></a>
      </div>
    </div>
  </div>
  <br>
  <div class="col">
    <div class="card"><!--<a href="#work">-->
      <img src="../images/layouts/viewpdfdisable.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">MODULO PENDIENTES DE REVISAR</h5>
        <p class="card-text">Modulo notas pendientes de revision.</p></a>
      </div>
    </div>
  </div>
  <script>

$(document).ready(function () {
 
 (function ($) {

	 $('#filtrar').keyup(function () {

		  var rex = new RegExp($(this).val(), 'i');

		  $('.buscar tr').hide();

		  $('.buscar tr').filter(function () {
			return rex.test($(this).text());
		  }).show();

	 })

 }(jQuery));

});
</script>
</body>
