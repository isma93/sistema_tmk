<HTML>
<H1>Hello</h1>

<?php
session_start(); 


//$_SESSION['contado']= 0;
if( isset( $_SESSION['contado'] ) ) {
    $_SESSION['contado'] += 1;

	
}else {
    $_SESSION['contado'] = 1;
	//echo $_SESSION['contado'];
	
}







$codigo=$_POST["codigo"];
$nombreProducto=$_POST["nombreProducto"];
$cantidad=$_POST["cantidad"];
$Entidad=$_POST["Entidad"];
$descripPromocion=$_POST["descripPromocion"];




?>

						

									<?php 
									if (empty($_SESSION['validadorv2'])){$_SESSION['validadorv2']=1;}else{$_SESSION['validadorv2']=$_SESSION['validadorv2']+1;}
									
								
									$i = 1;
									$u= $_SESSION['contado'];
									$_SESSION['codigo'.$u]=$codigo;
									$_SESSION['nombreProducto'.$u]=$nombreProducto;
									$_SESSION['cantidad'.$u]=$cantidad;					
									$_SESSION['Entidad'.$u]=$Entidad;
									$_SESSION['descripPromocion'.$u]=$descripPromocion;
									while ($i <= $_SESSION['contado']){
										?>
									
										<?php  $i++;
									} 
							
									echo '<script>
													  
										 window.location = "../create_invoice.php";
										
								</script>';
									
									?>
									</tr>

						</table>